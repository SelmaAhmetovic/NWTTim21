package com.calendar.calendarapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalendarappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalendarappApplication.class, args);
	}

}
